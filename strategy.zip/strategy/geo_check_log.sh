#!/bin/bash
sudo docker-compose logs -f
