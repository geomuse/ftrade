#!/bin/bash
sudo docker-compose ps
