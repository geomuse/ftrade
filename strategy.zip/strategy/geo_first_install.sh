#!/bin/bash
sudo docker-compose pull
sudo docker-compose up -d
