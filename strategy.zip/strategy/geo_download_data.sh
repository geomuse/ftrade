#! bin/bash
# sudo docker-compose run --rm freqtrade download-data --pairs-file ./user_data/data/pairs.json --days 60 --exchange binance --timeframes 1m 5m 1h --data-format-ohlcv hdf5 --data-format-trades hdf5
# sudo docker-compose run --rm freqtrade download-data --pairs-file ./user_data/data/pairs.json --days 60 --exchange binance --timeframes 1m 5m 1h --data-format-ohlcv hdf5 --data-format-trades hdf5 --trading-mode futures
# sudo docker-compose run --rm freqtrade download-data --pairs-file ./user_data/data/pairs.json --days 60 --exchange binance --timeframes 1m 5m --trading-mode futures
# sudo docker-compose run --rm freqtrade download-data --pairs-file ./user_data/data/pairs.json --timerange=20230101- --exchange binance --timeframes 1m 5m --trading-mode futures 
sudo docker-compose run --rm freqtrade download-data --pairs-file ./user_data/data/pairs.json --timerange=20230101- --exchange binance --timeframes 1m 5m
