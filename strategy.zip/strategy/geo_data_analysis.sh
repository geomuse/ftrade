#!/bin/bash
sudo docker-compose -f docker/docker-compose-jupyter.yml build --no-cache
# for new.
# docker compose -f docker/docker-compose-jupyter.yml up
