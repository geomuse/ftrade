#!bin/bash
sudo docker-compose run \
    --rm freqtrade new-config \
    --config user_data/geo-dry-run-config.json
