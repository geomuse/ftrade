#!/bin/bash
sudo docker-compose stop freqtrade
