#!bin/bash
sudo docker-compose run \
    --rm freqtrade backtesting \
    --strategy-list \
        sample_strategy \
        simple_sma_strategy \
        bollinger_bands_strategy \
        bollinger_bands_stable_strategy \
        geo_strategy \
        geo_v1_strategy \
        geo_v2_strategy \
        geo_v3_strategy \
        geo_v4_strategy \
    --config ./user_data/geo-config.json --timeframe 5m --breakdown day week --cache none --timerange=20230601-
